function [] = hoamon_plot_option_value_with_steps()

clc
clear

hold on
grid on

spot_price = 50;
strike_price = 50;
option_type = 'put';
delivery_type = 'american';
riskfree_rate = 0.1;
implied_volatility = 0.4;

total_duration = 5/12;
start_steps = 50;
end_steps = 60;

point = [];
for steps=start_steps:end_steps
    step_duration = total_duration / steps;
    value = hoamon_get_option_price( spot_price, strike_price, ...
        option_type, delivery_type, steps, step_duration, riskfree_rate, implied_volatility );
    point = [point value]
end

plot([start_steps:1:end_steps], point, '--g^')