function [  ] = hoamon_get_implied_volatility(  )

days_in_year = 252;                 %�@�~���X��
precision = 10^-3;
today = datenum('28-Jan-2005');
spot_price = 83.25;
riskfree_rate = 0.05;
option_type = 'put';
delivery_type = 'american';

option_data = [
    85,         2.35,       datenum('18-Feb-2005');
    85,         3.10,       datenum('18-Mar-2005');
    85,         3.40,       datenum('15-Apr-2005');
    85,         4.60,       datenum('15-Jul-2005');
    85,         6.50,       datenum('20-Jan-2006');
    85,         8.60,       datenum('19-Jan-2007');    
];
option_data_size = size(option_data);

for i=1:option_data_size(1)
    plus = [0.00001];
    minus = [10];
    implied_volatility = (plus(1) + minus(1))/2;
    diff = 1;
    while abs(diff) > precision
        cal_value = hoamon_get_option_price( spot_price, option_data(i, 1), ...
            option_type, delivery_type, ...
            round((option_data(i, 3)-today)*days_in_year/365), ...
            1 / days_in_year, riskfree_rate, implied_volatility );
        diff = option_data(i, 2) - cal_value;
        if diff > 0
            plus = [implied_volatility, plus];
        elseif diff < 0
            minus = [implied_volatility, minus];
        else
            break
        end
        implied_volatility = (plus(1) + minus(1))/2;
    end
    sprintf('option %d: %f', i, implied_volatility)
end