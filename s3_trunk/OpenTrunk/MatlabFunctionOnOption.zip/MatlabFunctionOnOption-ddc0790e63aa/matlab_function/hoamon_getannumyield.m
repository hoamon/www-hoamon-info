function [annumyield] = hoamon_getannumyield(Ci, Ni)

precision = 10^-10;
plus = [0];
minus = [1];

%present_value_0 = hoamon_getpresentvalue(plus(1), Ci, Ni);
%present_value_1 = hoamon_getpresentvalue(minus(1), Ci, Ni);
annumyield = (plus(1) + minus(1)) / 2;

while abs(annumyield - plus(1)) > precision | abs(annumyield - minus(1)) > precision
    present_value = hoamon_getpresentvalue(annumyield, Ci, Ni);
    if present_value > 0
        plus = [annumyield, plus];
    elseif present_value < 0
        minus = [annumyield, minus];
    else
        break
    end
    annumyield = (plus(1) + minus(1)) / 2;
end