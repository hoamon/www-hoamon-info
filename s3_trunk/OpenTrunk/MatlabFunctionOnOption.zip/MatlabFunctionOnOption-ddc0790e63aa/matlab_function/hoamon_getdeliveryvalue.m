function [ value ] = hoamon_get_delivery_value( spot_price, strike_price, option_type )

value = strike_price - spot_price;
if strcmp(option_type, 'put')
    if value < 0
        value = 0;
    end
else
    value = value * -1;
    if value < 0
        value = 0;
    end
end
