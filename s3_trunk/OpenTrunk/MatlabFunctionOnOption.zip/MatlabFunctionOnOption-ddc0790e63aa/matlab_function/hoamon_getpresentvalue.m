function [ present_value ] = hoamon_getpresentvalue( discount_rate, Ci, Ni )

present_value = 0;
Ci_size = size(Ci);
for i = 1:Ci_size(2)
    present_value = present_value + Ci(i)*(1+discount_rate)^(-1*Ni(i));
end