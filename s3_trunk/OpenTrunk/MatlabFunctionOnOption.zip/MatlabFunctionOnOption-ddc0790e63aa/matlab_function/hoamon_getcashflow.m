function [cash_flow, time_period] = hoamon_getcashflow(cost, par_value, coupon_duration, ...
    bid_date, maturity_date, coupon_rate)

days_in_year = 365;                 %�@�~���X��
coupon_value = par_value * coupon_rate * ( coupon_duration / 12 );
cash_flow = [par_value+coupon_value];
coupon_date = datemnth(maturity_date, -1*coupon_duration);

while coupon_date > bid_date
    day_delta = coupon_date - bid_date;
    cash_flow = [coupon_value, cash_flow];
    coupon_date = datemnth(coupon_date, -1*coupon_duration);
end

cash_flow = [-1*cost-coupon_value*(1-day_delta/days_in_year), cash_flow];
time_period_size = size(cash_flow) - 1;
time_period = [0, day_delta/days_in_year:1:time_period_size(2)];