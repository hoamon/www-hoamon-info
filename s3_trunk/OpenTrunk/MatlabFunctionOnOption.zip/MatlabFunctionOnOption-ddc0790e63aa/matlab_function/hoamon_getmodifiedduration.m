function [ modified_duration ] = hoamon_getmodifiedduration( cost, yieldrate, coupon_duration, Ci, Ni )

income_Ci = Ci;
income_Ci(1) = income_Ci(1) + cost;

Ci_size = size(Ci);
discount_list = ones(1, Ci_size(2)) / (1+yieldrate);
for i = 1:Ci_size(2)
    discount_list(i) = discount_list(i) ^ Ni(i);
end    

duration = sum(income_Ci .* Ni .* discount_list) / Ci(1) * -1;
modified_duration = duration / (1+yieldrate/(coupon_duration/12));
