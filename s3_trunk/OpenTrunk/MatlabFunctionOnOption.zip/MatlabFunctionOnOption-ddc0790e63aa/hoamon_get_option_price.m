function [ value ] = hoamon_get_option_price( spot_price, strike_price, ...
    option_type, delivery_type, steps, step_duration, riskfree_rate, implied_volatility )
% spot_price         �Ъ�������
% strike_price       �i����
% option_type        �R�v or ���v
% delivery_type      european or american
% steps              �ѻ����B���B��
% step_duration      �C�@�B���@�~�����
% riskfree_rate      �L���I�Q�v
% implied_volatility ���t�i�ʲv

% spot_price = 50;
% strike_price = 52;
% option_type = 'put';
% delivery_type = 'american';
% steps = 2;
% step_duration = 1;
% riskfree_rate = 0.05;
% implied_volatility = 0.2;

d = exp(1)^(-1 * implied_volatility * step_duration^0.5);
u = exp(1)^( 1 * implied_volatility * step_duration^0.5);
P = (exp(1)^(riskfree_rate*step_duration) - d) / (u - d);

spot_tree = zeros(steps+1, steps+1);
option_tree = zeros(steps+1, steps+1);

for i=1:steps+1
    for j=1:i
        if i == 1 & j == 1
            spot_tree(i, j) = spot_price;
        elseif j == 1
            spot_tree(i, j) = spot_tree(i-1, j) * u;
        else
            spot_tree(i, j) = spot_tree(i-1, j-1) * d;
        end
    end
end

for i=1:steps+1
    option_tree(steps+1, i) = hoamon_getdeliveryvalue(spot_tree(steps+1, i), ...
        strike_price, option_type);
end

for level=1:steps
    i = steps + 1 - level;
    for j=1:i
        cal_value = exp(1)^(-1*riskfree_rate*step_duration) * ...
            ( option_tree(i+1, j) * P + option_tree(i+1, j+1) * (1 - P) );
        if strcmp(delivery_type, 'european')
            option_tree(i, j) = cal_value;
        else
            delivery_value = hoamon_getdeliveryvalue(spot_tree(i, j), strike_price, option_type);
            if delivery_value > cal_value
                option_tree(i, j) = delivery_value;
            else
                option_tree(i, j) = cal_value;
            end
        end
    end
end

value = option_tree(1, 1);