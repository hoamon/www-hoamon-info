function [zerobond_abc] = hoamon_plot_zero_coupon_curve(show_plot)
% �� show_plot == true �ɡA�|ø�s�ާQ�v���u�ϡC

clc

if show_plot
    hold on
    grid on
end

days_in_year = 365;                 %�@�~���X��
par_value = 100;                    %�Ũ魱�B
coupon_duration = 12;               %�C12�Ӥ�t��
bid_date = datenum(2009, 4, 16);    %�[���
%   cost       coupon_rate     macaulay_date           yieldrate   modify_duration
bond_data = [
    110.4412    0.03            datenum(2024, 11, 18)   0           0; %A93109
    100.3904    0.01625         datenum(2015, 9, 12)    0           0; %A94107
    102.3168    0.0175          datenum(2011, 1, 6)     0           0; %'A95101'
    100.6188    0.0175          datenum(2016, 3, 31)    0           0; %'A95103'
    103.0834    0.01875         datenum(2012, 1, 26)    0           0; %'A96101'
    103.8367    0.02125         datenum(2018, 9, 24)    0           0; %'A97106'
    99.2679     0.00875         datenum(2014, 1, 21)    0           0; %'A98101'
    98.8824     0.02125         datenum(2029, 2, 16)    0           0; %'A98102'
    98.5211     0.01375         datenum(2019, 3, 5)     0           0; %'A98103'
];

bond_data_size = size(bond_data);
PVs = [];
zero_PVs = [];
X = [];
zero_X = [];
for i = 1:bond_data_size(1)
    [Ci, Ni] = hoamon_getcashflow(bond_data(i, 1), par_value, coupon_duration, ...
        bid_date, bond_data(i, 3), bond_data(i, 2));
    bond_data(i, 4) = hoamon_getannumyield(Ci, Ni);
    bond_data(i, 5) = hoamon_getmodifiedduration(bond_data(i, 1), bond_data(i, 4), ...
        coupon_duration, Ci, Ni);
    
    if show_plot
        plot((bond_data(i, 3)-bid_date)/days_in_year, bond_data(i, 4), '--rs')
        plot(bond_data(i, 5), bond_data(i, 4), '--g^')
        text((bond_data(i, 3)-bid_date)/days_in_year+0.2, bond_data(i, 4), sprintf('%5.2f', (bond_data(i, 3)-bid_date)/days_in_year))
        text(bond_data(i, 5)-1, bond_data(i, 4), sprintf('%5.2f', bond_data(i, 5)))
    end    
    Ci_size = size(Ci);
    
    PVs = [PVs; Ci(1)];
    newCi = Ci(2:Ci_size(2));
    newNi = [
        ones(1, Ci_size(2)-1);
        Ni(2:Ci_size(2));
        Ni(2:Ci_size(2)) .* Ni(2:Ci_size(2));
        Ni(2:Ci_size(2)) .* Ni(2:Ci_size(2)) .* Ni(2:Ci_size(2));
    ]';
    X = [X; newCi * newNi];
    
    zero_PVs = [zero_PVs; Ci(1)];
    zero_newCi = [-1*Ci(1)*(1+bond_data(i, 4))^bond_data(i, 5)];
    zero_newNi = [
        [1];
        [bond_data(i, 5)];
        [bond_data(i, 5)] .* [bond_data(i, 5)];
        [bond_data(i, 5)] .* [bond_data(i, 5)] .* [bond_data(i, 5)];
    ]';
    zero_X = [zero_X; zero_newCi * zero_newNi];
end
PVs = PVs(:, 1) + X(:, 1);
X = X(:, 2:4);
zero_PVs = zero_PVs(:, 1) + zero_X(:, 1);
zero_X = zero_X(:, 2:4);

bond_abc = inv(X'*X)*X'*PVs*-1;
zerobond_abc = inv(zero_X'*zero_X)*zero_X'*zero_PVs*-1;

x0 = ones(1, 20);
x1 = [1:1:20];
x2 = x1 .* x1;
x3 = x1 .* x2;

zero_x1 = x1 * zerobond_abc(1);
zero_x2 = x2 * zerobond_abc(2);
zero_x3 = x3 * zerobond_abc(3);

x1 = x1 * bond_abc(1);
x2 = x2 * bond_abc(2);
x3 = x3 * bond_abc(3);

D = x0 + x1 + x2 + x3;
zero_D = x0 + zero_x1 + zero_x2 + zero_x3;

Y = zeros(1, 20);
zero_Y = zeros(1, 20);

for i = 1:20
    Y(i) = (1/D(i))^(1/i) - 1;
    zero_Y(i) = (1/zero_D(i))^(1/i) - 1;
end

if show_plot
	plot([1:1:20], Y, '--r');
	plot([1:1:20], zero_Y, '--g');
end