#! /usr/bin/python
#-*- coding:utf8 -*-

class AnnumYield:
    """ 求解年化殖利率。
    """

    def __init__(self, PV=0, Ci=[], Ni=[], precision=6, start_rate=0, end_rate=1):
        """ Ci: 第 i 個現金流量
            Ni: 第 i 個期別的真實時間
            PV: 現值。為債券購入價格，其值應為負值。
            precision: 數值分析時的精度，當殖利率變化值小於 10**(-1*precision) ，則停止求解。
            start_rate，end_rate: 起始利率。

            self.equation: 現金流量的方程式
            self.yieldrate: 債券殖利率
        """
        self.Ci = Ci
        self.Ni = len(Ni) != 0 and Ni or range(len(Ci))
        self.PV = PV < 0 and PV or -1*PV
        self.precision = precision
        self.start_rate = start_rate
        self.end_rate = end_rate

        equations = []
        for i, c in enumerate(Ci):
            equations.append('%s/(1+r)**(%s)'%(c, self.Ni[i]))
        self.equation = '%s + ' % self.PV + ' + '.join(equations)

        self.yieldrate = self.getYield()

    def getYield(self):
        """ 利用二分逼近法求 self.equation 的根。
            當所求出的 yieldrate 與前一個解的差值小於 10 ** (-1*precision) 即停止求解。

            預設代入 start_rate 及 end_rate 去作逼近，
            所以真實的 yieldrate 必須滿足 start_rate < yieldrate < end_rate 的條件，
            否則無解。
        """
        r = self.start_rate
        self.list = [(self.start_rate, eval(self.equation))]
        r = self.end_rate
        self.list.append((self.end_rate, eval(self.equation)))

        i0, (r0, res0) = 0, self.list[0]
        i1, (r1, res1) = 1, self.list[1]
        precision = 10 ** (-1*self.precision)
        while abs(r0 - r1) > precision:
            r = (r0 + r1)/2.
            res = eval(self.equation)
            self.list.insert(i1, (r, res))
            if res * res0 < 0:
                i0, (r0, res0) = i1-1, self.list[i1-1]
                i1, (r1, res1) = i1  , self.list[i1]
            elif res * res1 < 0:
                i0, (r0, res0) = i1  , self.list[i1]
                i1, (r1, res1) = i1+1, self.list[i1+1]
            elif res == 0:
                break
            else:
                raise ValueError, \
                    '無解。 end_rate 設定為 %s ，此數值比 yieldrate 解還小' % self.end_rate

        return round((r0 + r1)/2., self.precision)


class ModifiedDuration:
    """ 存續期間 D 的公式定義如下：
        D = \frac{\sum_{i=1}^{n} \frac{t_{i}C_{i}}{(1+y)^{t_{i}}}}{B}

        再經殖利率 y 的修正後，得到 D^{*}

        D^{*} = \frac{D}{1+\frac{y}{m}}
        y: 為年化殖利率
        m: 為每幾個月配息一次

    """
    def __init__(self, PV=0, Ci=[], Ni=[], yieldrate=0, coupon_duration=12):
        self.PV = PV < 0 and -1*PV or PV
        self.Ci = Ci
        self.Ni = len(Ni) != 0 and Ni or range(len(Ci))
        self.yieldrate = yieldrate
        self.coupon_duration = coupon_duration

        equations = []
        for i, c in enumerate(Ci):
            equations.append('%s*%s/(1+%s)**(%s)'%(self.Ni[i], c,
                self.yieldrate, self.Ni[i]))
        self.equation = ' + '.join(equations)
        self.D = eval(self.equation) / self.PV
        self.modified_duration = round(self.D/(1+
            self.yieldrate/(self.coupon_duration/12)), 2)


from numpy import *
class CubicSpline:
    """ 使用最小平方和原則作三次方方程式的迴歸
    """
    def __init__(self, same_as_yayaya=False):
        self.same_as_yayaya = same_as_yayaya
        self.PVs = array([])
        self.X = array([])
    
    def addBondData(self, PV=0, Ci=[], Ni=[]):
        self.PV = PV < 0 and PV or -1*PV
        if Ni[0] == 0:
            if self.same_as_yayaya:
                self.PVs = append(self.PVs, -1*self.PV) # 使用此式時，答案才會與課代相同
            else:
                self.PVs = append(self.PVs, -1*self.PV-Ci[0])
            self.Ci = array(Ci[1:])
            self.Ni = array([[1, t, t**2, t**3] for t in Ni[1:]])
        else:
            self.PVs = append(self.PVs, -1*self.PV)
            self.Ci = array(Ci)
            self.Ni = array([[1, t, t**2, t**3] for t in Ni])

        self.dt = dot(self.Ci, self.Ni)
        if len(self.X):
            self.X = append(self.X, [self.dt[1:]], axis=0)
        else:
            self.X = array([self.dt[1:]])

        self.PVs[-1] -= self.dt[0]

    def runOLS(self):
        self.X = matrix(self.X)
        self.PVs = matrix(self.PVs).T
        self.b = linalg.inv(self.X.T * self.X) * self.X.T * self.PVs
        return self.b


from math import log, e
class YieldCurve:
    """ 依據給定的點繪製殖利率曲線

        使用殖利率公式
        self.dFunc = '1 + a*t + b*t**2 + c*t**3'
        self.yFunc = '(1/Dt)^(1/t) - 1'
    """
    def __init__(self, t_points=[], Da=0, Db=0, Dc=0, same_as_yayaya=False):
        self.t_points = t_points
        self.dFunc = '1 + %f*t + %f*t**2 + %f*t**3' % (Da, Db, Dc)
        if same_as_yayaya:
            self.yFunc = '(-1./t)*log(Dt, e)'
        else:
            self.yFunc = '(1./Dt)**(1./t) - 1'

        self.getY()

    def getY(self):
        self.y_points = y_points = []
        for t in self.t_points:
            Dt = eval(self.dFunc)
            y_points.append(eval(self.yFunc))
        
        return y_points

from datetime import date
from monthdelta import monthdelta # http://packages.python.org/MonthDelta/
from pylab import plot, show, text, grid
def getCashFlow(par_value=None, coupon_duration=None, bid_date=None,
    maturity_date=None, coupon_rate=None):
    coupon_value = par_value * coupon_rate * ( coupon_duration / 12 )
    cash_flow = [par_value+coupon_value]
    coupon_date = maturity_date - monthdelta(coupon_duration)
    while coupon_date > bid_date:
        day_delta = (coupon_date - bid_date).days
        cash_flow.insert(0, coupon_value)
        coupon_date -= monthdelta(coupon_duration)
    cash_flow.insert(0, -1*coupon_value*(1-day_delta/365.))
    time_period = [0,]
    for i in xrange(len(cash_flow)-1):
        time_period.append(i+day_delta/365.)

    return cash_flow, time_period

if __name__ == "__main__":
    par_value = 100
    coupon_duration = 12 # 12個月
    bid_date = date(2009, 4, 16)
    bond_data = {
        'A93109': {
            'cost': 110.4412,
            'coupon_rate': 0.03,
            'maturity_date': date(2024, 11, 18),
        },
        'A94107': {
            'cost': 100.3904,
            'coupon_rate': 0.01625,
            'maturity_date': date(2015, 9, 12),
        },
        'A95101': {
            'cost': 102.3168,
            'coupon_rate': 0.0175,
            'maturity_date': date(2011, 1, 6),
        },
        'A95103': {
            'cost': 100.6188,
            'coupon_rate': 0.0175,
            'maturity_date': date(2016, 3, 31),
        },
        'A96101': {
            'cost': 103.0834,
            'coupon_rate': 0.01875,
            'maturity_date': date(2012, 1, 26),
        },
        'A97106': {
            'cost': 103.8367,
            'coupon_rate': 0.02125,
            'maturity_date': date(2018, 9, 24),
        },
        'A98101': {
            'cost': 99.2679,
            'coupon_rate': 0.00875,
            'maturity_date': date(2014, 1, 21),
        },
        'A98102': {
            'cost': 98.8824,
            'coupon_rate': 0.02125,
            'maturity_date': date(2029, 2, 16),
        },
        'A98103': {
            'cost': 98.5211,
            'coupon_rate': 0.01375,
            'maturity_date': date(2019, 3, 5),
        },
    }
    keys = bond_data.keys()
    keys.sort()
    duration_plot = []
    cubic_spline = CubicSpline()
    cubic_spline_use_macaulay_duration = CubicSpline()
    cubic_spline_same_as_yayaya = CubicSpline(same_as_yayaya=True)
    for name in keys:
        bond = bond_data[name]
        Ci, Ni = getCashFlow(par_value=par_value, coupon_duration=coupon_duration,
        bid_date=bid_date, maturity_date=bond['maturity_date'],
        coupon_rate=bond['coupon_rate'])

        annumyield = AnnumYield(Ci=Ci, Ni=Ni, PV=bond['cost'])
        bond_data[name]['yieldrate'] = annumyield.yieldrate

        md = ModifiedDuration(PV=annumyield.PV+annumyield.Ci[0],
            Ci=annumyield.Ci[1:], Ni=annumyield.Ni[1:],
            yieldrate=annumyield.yieldrate)
        bond_data[name]['modified_duration'] = md.modified_duration
        
        duration_plot.append((bond_data[name]['modified_duration'],
            bond_data[name]['yieldrate']))

        x = bond_data[name]['modified_duration']
        x2 = Ni[-1]
        y = bond_data[name]['yieldrate']*100.
        plot([x], [y], 'g^')
        plot([x2], [y], 'r+')
        text(x, y+0.03, '%5.4f%%:%5.2f>%5.2f' % (y, x2, x))


        cubic_spline.addBondData(PV=annumyield.PV, Ci=Ci, Ni=Ni)
        cubic_spline_use_macaulay_duration.addBondData(PV=annumyield.PV,
            Ci=[-1*annumyield.PV*(1+annumyield.yieldrate)**md.modified_duration],
            Ni=[md.modified_duration])
        print annumyield.PV, annumyield.PV*(1+annumyield.yieldrate)**md.modified_duration,\
            md.modified_duration
        cubic_spline_same_as_yayaya.addBondData(PV=annumyield.PV, Ci=Ci, Ni=Ni)

    cubic_spline.runOLS()
    cubic_spline_use_macaulay_duration.runOLS()
    cubic_spline_same_as_yayaya.runOLS()

    t_points = arange(1., 30, 1.)

    print cubic_spline.b
    Da, Db, Dc = cubic_spline.b
    yc = YieldCurve(t_points, Da=Da, Db=Db, Dc=Dc, same_as_yayaya=False)
    plot(t_points, [y*100 for y in yc.y_points], 'r-')

    # use zero bond
    print cubic_spline_use_macaulay_duration.b
    Da, Db, Dc = cubic_spline_use_macaulay_duration.b
    yc = YieldCurve(t_points, Da=Da, Db=Db, Dc=Dc)
    print [y for y in yc.y_points]
    plot(t_points, [y*100 for y in yc.y_points], 'g-')

#    print cubic_spline_same_as_yayaya.b
#    Da, Db, Dc = cubic_spline_same_as_yayaya.b
#    yc = YieldCurve(t_points, Da=Da, Db=Db, Dc=Dc)
#    plot(t_points, [y*100 for y in yc.y_points], 'y>')

    grid()
    show()


